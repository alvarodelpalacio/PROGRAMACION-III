import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        
        int opcion;
        int ritmoLectura=1;
        int cantidadLibros=1;
        Almacen nuevoAlmacen = null;
        int tamano=0;

        Scanner scanner = new Scanner(System.in);

        do{
        System.out.println("1) Nuevo almacén de libros\r\n" + 
                           "2) Establecer ritmo de lectura (páginas por minuto)\r\n" + //
                           "3) Añadir un nuevo libro al almacén\r\n" + 
                           "4) Mostrar información actual de libros\r\n" + 
                           "5) Salir (se borrará toda la información)");
        opcion = scanner.nextInt();

        switch (opcion) {
            case 1:
                System.out.println("Introduce el tamaño del nuevo almacen");
                tamano = scanner.nextInt();
                nuevoAlmacen = new Almacen(tamano);
                System.out.println("Almacen creadon correctamente");
                break;  
            case 2:
                System.out.println("Introduce el ritmo de lectura:");
                ritmoLectura = scanner.nextInt();
                break;
            case 3:
            if (nuevoAlmacen != null) {
                nuevoAlmacen.agregarLibro(tamano); 
                System.out.println("Libro añadido correctamente");
            }
            else {
                System.out.println("Error: Primero debes crear un almacén (opción 1).");
            }
            break; 
            case 4:
                if (nuevoAlmacen != null) {
                    nuevoAlmacen.mostrarLibros();  
                } else {
                    System.out.println("Error: No hay un almacén creado.");
                }
                break;  
             case 5:
                System.out.println("Saliendo del programa... Se borrará toda la información.");
                nuevoAlmacen = null;  // Opcional: Limpiar el almacén
                scanner.close();  // Cerramos el scanner
                break;        
            default:
                
                break;
        }}while(opcion!=5);


    }

}

