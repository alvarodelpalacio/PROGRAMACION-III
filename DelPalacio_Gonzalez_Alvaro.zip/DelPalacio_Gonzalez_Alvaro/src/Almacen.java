import java.util.Scanner;

public class Almacen {
    private Libro1[] vlibros;
    
    
    public Almacen(int cantidad) {
        this.vlibros = new Libro1[cantidad];
        
    }


    //FUNCION PARA AGREGAR EL LIBRO
    public void agregarLibro(int tamano ) {
        
            Scanner scanner = new Scanner(System.in);

            //AUTOR------------------------------------------------------------------
            System.out.println("Ingresa el nombre del autor:");
            String nombreAutor = scanner.nextLine();

            System.out.println("Ingresa los apellidos del autor:");
            String apellidosAutor = scanner.nextLine();

            boolean premioPlaneta = false;
            while (true) {
                System.out.println("¿El autor ha ganado el Premio Planeta? (si/no):");
                String respuestaPremio = scanner.nextLine().toLowerCase();
                if (respuestaPremio.equals("si")) {
                    premioPlaneta = true;
                    break;
                } else if (respuestaPremio.equals("no")) {
                    premioPlaneta = false;
                    break;
                } else {
                    System.out.println("Por favor, responde 'si' o 'no'.");
                }
            }
            Autor autor = new Autor(nombreAutor, apellidosAutor, premioPlaneta);

            
            //LIBRO-------------------------------------------------------------------------
            System.out.println("Ingresa el título del libro:");
            String titulo = scanner.nextLine();

            int anioPublicacion = 0;
                System.out.println("Ingresa el año de publicación:");
                anioPublicacion = scanner.nextInt();
            
            int numeroPaginas = 0;
                System.out.println("Ingresa el número de páginas:");
                numeroPaginas = scanner.nextInt();
                    
            double precio = 0;
                System.out.println("Ingresa el precio del libro:");
                    precio = scanner.nextDouble();
                    
        
            Libro1 nuevoLibro = new Libro1 (autor, titulo, anioPublicacion, numeroPaginas, precio);


            //INSERTAR LIBRO
            for (int i = 0; i < tamano; i++) {
                if (vlibros[i] == null) {
                    vlibros[i] = nuevoLibro;
                    return;  
                }
            }


    }
    //MOSTRAR LIBROS
    public void mostrarLibros() {

        for (int i = 0; i < vlibros.length; i++) {
            if (vlibros[i] != null) {
                
                System.out.println("Libro " + (i + 1) + ":");
                System.out.println("   Título: " + vlibros[i].getTitulo());
                System.out.println("   Autor: " + vlibros[i].getAutor().getNombre() + " " + vlibros[i].getAutor().getApellidos());
                System.out.println("   Año de publicación: " + vlibros[i].getAnioPublicacion());
                System.out.println("   Número de páginas: " + vlibros[i].getNumeroPaginas());
                System.out.println("   Precio: " + vlibros[i].getPrecio());
                System.out.println();
            }
        }
    }

}


            
    

        
