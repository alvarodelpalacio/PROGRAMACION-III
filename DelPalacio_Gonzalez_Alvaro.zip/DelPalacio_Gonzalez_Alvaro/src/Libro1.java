public class Libro1 {
        private Autor autor;
        private String titulo;
        private int anioPublicacion;
        private int numeroPaginas;
        private double precio;
    
        public Libro1(Autor autor, String titulo, int anioPublicacion, int numeroPaginas, double precio) {
                this.autor = autor;
                this.titulo = titulo;
                this.anioPublicacion = anioPublicacion;
                this.numeroPaginas = numeroPaginas;
                this.precio = precio;
            }

        public Autor getAutor() {
                return autor;
        }

        public void setAutor(Autor autor) {
                this.autor = autor;
        }

        public String getTitulo() {
                return titulo;
        }

        public void setTitulo(String titulo) {
                this.titulo = titulo;
        }

        public int getAnioPublicacion() {
                return anioPublicacion;
        }

        public void setAnioPublicacion(int anioPublicacion) {
                this.anioPublicacion = anioPublicacion;
        }

        public int getNumeroPaginas() {
                return numeroPaginas;
        }

        public void setNumeroPaginas(int numeroPaginas) {
                this.numeroPaginas = numeroPaginas;
        }

        public double getPrecio() {
                return precio;
        }

        public void setPrecio(double precio) {
                this.precio = precio;
        }
        
    }

    
    
    
